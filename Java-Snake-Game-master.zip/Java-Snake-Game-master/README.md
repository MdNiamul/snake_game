# Java-Snake-Game
Java Snake game source code

https://zetcode.com/javagames/snake/  

![Snake game screenshot](snake.png)
